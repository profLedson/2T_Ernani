// SELECIONAR
const nome = document.getElementById('nome');
const sobrenome = document.getElementById('sobrenome');

// MANIPULAR
const novoNome = "Brunão"
const novoSobrenome = "Carrara"

nome.innerText = novoNome;
sobrenome.innerText = novoSobrenome3